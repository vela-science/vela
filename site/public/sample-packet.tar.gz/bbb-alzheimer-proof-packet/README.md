# BBB Flagship packet

Bounded flagship frontier for BBB delivery strategies for Alzheimer's-relevant therapeutics. Curated from checked-in abstract-level source files under projects/bbb-flagship/raw.

This export is a bounded network packet: a compact, publishable subset of the frontier optimized for review, contradiction inspection, and grounded agent context. It intentionally does not dump the full raw frontier by default.

## Source

- Project: BBB Flagship
- Compiled at: 2026-04-22T00:00:00Z
- Generated at: 2026-04-26T04:43:48.014150+00:00
- Compiler: vela/0.8.0
- Vela version: 0.8.0
- Schema: https://vela.science/schema/finding-bundle/v0.8.0

## Included artifacts

- `manifest.json` — provenance, version stamp, checksums
- `overview.json` — project-level stats, categories, top entities
- `findings/high-signal.json` — compact high-signal finding subset
- `findings/full.json` — canonical finding bundles for packet import and merge
- `findings/gaps.json` — gap-tagged findings
- `findings/contested.json` — contested findings
- `findings/bridges.json` — entities spanning multiple assertion categories
- `findings/contradictions.json` — explicit contradiction/dispute edges
- `reviews/review-events.json` — attached review events
- `reviews/confidence-updates.json` — interpretation confidence revisions
- `state-transitions.json` — combined review and confidence transition log

## Packet stats

- Findings in source frontier: 48
- High-signal findings exported: 43
- Gap findings exported: 1
- Contested findings exported: 1
- Bridge entities exported: 12
- Contradiction edges exported: 0
- Review events exported: 0
